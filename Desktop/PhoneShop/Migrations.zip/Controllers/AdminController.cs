﻿using PhoneShop.Models.DataContextZ;
using PhoneShop.Models.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace PhoneShop.Controllers
{
    public class AdminController : Controller
    {
        private DatabaseContext db = new DatabaseContext();
        // GET: Admin
        public ActionResult Index()
        {

            return View();
        }

        public ActionResult List()
        {
            return View(db.Admins.ToList());
        }
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Admin admin = db.Admins.Find(id);
            if (admin == null)
            {
                return HttpNotFound();
            }
            return View(admin);
        }
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,adminName,userName,hashedPassword,isSuperAdmin,createDate,lastestAccess")] Admin admin)
        {
            if (ModelState.IsValid)
            {
                //string hashed = admin.hashedPassword;
                //MD5CryptoServiceProvider hasher = new MD5CryptoServiceProvider();
                //string zz = string.Concat("ummm salty " + hashed);
                //byte[] t = hasher.ComputeHash(Encoding.Unicode.GetBytes(zz));
                //hashed = Encoding.Unicode.GetString(t);
                //admin.hashedPassword = hashed;
                
                db.Admins.Add(admin);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(admin);
        }

    }
}