﻿using PhoneShop.Models.DataContextZ;
using PhoneShop.Models.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PhoneShop.Controllers
{
    public class AccountsController : Controller
    {
        private DatabaseContext db = new DatabaseContext();
        // GET: Accounts
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(string uname, string pass)
        {
            List<Customer> customers = db.Customers.ToList();
            List<Admin> admins = db.Admins.ToList();
            foreach(Customer c in customers)
            {
                if(c.email == uname && c.hashedPassword == pass)
                {
                    //work with session and stuff
                    return RedirectToAction("Index", "Home");
                }                
            }
            foreach(Admin a in admins)
            {
                if(a.userName == uname && a.hashedPassword == pass)
                {
                    //work with session and stuff
                    return RedirectToAction("Index", "Admin");
                }
            }
            return View("Login");
        }
        public ActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Register(Customer customer)
        {
            if (ModelState.IsValid)
            {
                db.Customers.Add(customer);
                db.SaveChanges();
                return RedirectToAction("Login");
            }
            return View();
        }
    }
}