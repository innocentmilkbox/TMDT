﻿using PhoneShop.Models.DataContextZ;
using PhoneShop.Models.DisplayOnView;
using PhoneShop.Models.Domain;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PhoneShop.Controllers
{
    public class HomeController : Controller
    {
        DatabaseContext db = new DatabaseContext();
        public ActionResult Index()
        {          
            return View(db.Products.Include("Categories").Take(8).ToList());
        }
        
        
        public ActionResult ProductList(string catName, int? page)
        {            
            int k = 0;
            if (page != null)
            {
                k = (page.GetValueOrDefault()-1) * 12;
            }
            List<Product> products = new List<Product>();
            int t = 0;
            if (catName == "all")
            {
                products = db.Products.OrderBy(p => p.Id).Skip(k).Take(12).Include(x => x.Categories).ToList();
                t = db.Products.ToList().Count();
            }
            else
            {
                products = db.Products.Where(x => x.Categories.Name == catName).OrderBy(p => p.Id).Skip(k).Take(12).Include(x => x.Categories).ToList();
                t = db.Products.Where(x => x.Categories.Name == catName).ToList().Count();
            }
            
            int z = t / 12;
            if (z % 12 != 0) z++;
            ViewBag.countPage = z;
            ViewBag.Count = products.Count();
            //if (page == null) page = 1;
            //ViewBag.page = page;
            ViewBag.category = catName;
            return View(products);
        }
        public ActionResult ProductDetails(int? id)
        {
            if (id == null) return RedirectToAction("NotFound");                        
            Product p = db.Products.Include("Categories").Where(k => k.Id == id).First();
            List<Product> products = db.Products.Include("Categories").Where(x => x.CategoryId == p.CategoryId).Take(6).ToList();
            //products.Add(p);  
            ViewBag.id = p.Id;
            ViewBag.img = p.imgPath;
            ViewBag.name = p.productName;
            ViewBag.price = p.PriceOut;
            ViewBag.stock = p.Stocked;
            ViewBag.category = p.Categories.Name;
            return View(products.ToList());
            
        }
        
        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}